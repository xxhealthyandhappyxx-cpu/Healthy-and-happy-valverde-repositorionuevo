/* ==========================================
   HEALTHY & HAPPY VALVERDE - JAVASCRIPT
   Interactividad, dropdowns, form y animaciones
   ========================================== */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar funciones
    initHamburgerMenu();
    initDropdowns();
    initFormValidation();
    initSmoothScroll();
    initScrollAnimations();
    initFooterContactModal(); // Modal de contacto del footer
    initServiciosModals(); // <-- AÑADIMOS LA INICIALIZACIÓN DE LOS NUEVOS MODALES
    initApoyanosModals(); // <-- INICIALIZAR MODALES DE APÓYANOS
    initContactDirectoModal(); // <-- INICIALIZAR MODAL DE CONTACTO DIRECTO
    initPreorderModal(); // <-- INICIALIZAR MODAL DE PREORDER DEL LIBRO
    initTestimonialSlider(); // <-- INICIALIZAR CARRUSEL DE TESTIMONIOS
    initTransformationCarousel(); // <-- INICIALIZAR NUEVO CARRUSEL DE GALERÍA
    initCountdownTimer(); // <-- INICIALIZAR COUNTDOWN TIMER
});

// ========================================== 
// MENÚ HAMBURGUESA
// ========================================== 

function initHamburgerMenu() {
    const hamburger = document.getElementById('hamburger');
    const navbar = document.getElementById('navbar');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navbar.classList.toggle('active');
            hamburger.classList.toggle('active');
        });

        // Cerrar menú al hacer clic en un link
        const navLinks = navbar.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navbar.classList.remove('active');
                hamburger.classList.remove('active');
            });
        });
    }
}

// ========================================== 
// DROPDOWNS
// ========================================== 

function initDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');

    dropdowns.forEach(dropdown => {
        const toggle = dropdown.querySelector('.dropdown-toggle');
        
        toggle.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            }
        });
    });

    // Cerrar dropdowns al hacer clic fuera
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.dropdown')) {
            dropdowns.forEach(dropdown => {
                dropdown.classList.remove('active');
            });
        }
    });
}

// ========================================== 
// VALIDACIÓN DE FORMULARIOS
// ========================================== 

function initFormValidation() {
    const contactForm = document.getElementById('contactForm');
    const newsletterForm = document.getElementById('newsletterForm');

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleContactForm(this);
        });
    }

    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleNewsletterForm(this);
        });
    }
}

function handleContactForm(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    // Validación básica
    if (!data.name || !data.email || !data.message) {
        showNotification('Por favor completa todos los campos', 'error');
        return;
    }

    // Validar email
    if (!isValidEmail(data.email)) {
        showNotification('Por favor ingresa un email válido', 'error');
        return;
    }

    // Simular envío
    showNotification('¡Gracias por tu mensaje! Pronto nos pondremos en contacto.', 'success');
    form.reset();

    // En un caso real, aquí enviarías los datos a un servidor
    console.log('Formulario enviado:', data);
}

function handleNewsletterForm(form) {
    const email = form.querySelector('input[type="email"]').value;

    if (!isValidEmail(email)) {
        showNotification('Por favor ingresa un email válido', 'error');
        return;
    }

    showNotification('¡Gracias por suscribirse! Recibirás nuestras actualizaciones.', 'success');
    form.reset();
    console.log('Suscripción newsletter:', email);
}

function isValidEmail(email) {
    const regex = /^[^S@]+@[^S@]+\.[^S@]+$/;
    return regex.test(email);
}

function showNotification(message, type) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 9999;
        animation: slideInRight 0.3s ease;
        ${type === 'success' ? 'background-color: #2D9E82;' : 'background-color: #E63946;'}
    `;

    document.body.appendChild(notification);

    // Eliminar después de 3 segundos
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ========================================== 
// SCROLL SUAVE
// ========================================== 

function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            // Evitamos que el modal interfiera con el scroll suave
            if (href !== '#' && href !== '#home' && !this.id.includes('modal')) {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// ========================================== 
// ANIMACIONES AL SCROLL
// ========================================== 

function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Animar elementos
    const elements = document.querySelectorAll(
        '.service-card, .media-card, .about-content, .book-content'
    );

    elements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'all 0.6s ease';
        observer.observe(element);
    });
}

// ========================================== 
// NUEVA FUNCIONALIDAD: MODAL DE CONTACTO WHATSAPP
// ========================================== 

// ========================================== 
// MODAL DE CONTACTO GENERAL (ACTUALIZADO)
// ========================================== 

function initGeneralContactModal() {
    const modal = document.getElementById('contactModal');
    if (!modal) return; // Si el modal no existe, no hacer nada

    const openBtn = document.getElementById('open-contact-modal');
    const closeBtn = modal.querySelector('.close-button');
    const form = document.getElementById('whatsappForm'); // El ID del form sigue siendo whatsappForm

    // Botón de acción - SOLO EMAIL
    const sendEmailBtn = document.getElementById('sendEmail');

    if (!openBtn || !closeBtn || !form || !sendEmailBtn) {
        console.error('Elementos del modal de contacto general no encontrados.');
        return;
    }

    // --- DATOS PARA CONTACTO ---
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';
    
    // Abrir modal
    openBtn.addEventListener('click', function(e) {
        e.preventDefault();
        modal.style.display = 'block';
    });

    // Cerrar con el botón X
    closeBtn.addEventListener('click', () => modal.style.display = 'none');

    // Cerrar al hacer clic fuera
    window.addEventListener('click', event => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });

    // Función para obtener y validar datos del formulario
    function getValidatedData() {
        const name = document.getElementById('whatsappName').value.trim();
        const email = document.getElementById('whatsappEmail').value.trim();
        const message = document.getElementById('whatsappMessage').value.trim();

        if (!name || !email || !message) {
            showNotification('Por favor, rellena todos los campos.', 'error');
            return null;
        }
        if (!isValidEmail(email)) {
            showNotification('Por favor, introduce un email válido.', 'error');
            return null;
        }
        return { name, email, message };
    }

    // Lógica para Email (ÚNICO MÉTODO)
    sendEmailBtn.addEventListener('click', function() {
        const data = getValidatedData();
        if (!data) return;

        const subject = `Contacto desde la web: ${data.name}`;
        const body = `Hola,
Has recibido un nuevo mensaje de contacto desde la página web.

Nombre: ${data.name}
Email: ${data.email}
Mensaje:
${data.message}

---
Enviado desde el formulario de Healthy & Happy Valverde.`;

        const url = `mailto:${emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.location.href = url;
        showNotification('¡Gracias! Abriendo tu cliente de email.', 'success');
        cleanup();
    });

    // Función para limpiar y cerrar el modal
    function cleanup() {
        setTimeout(() => {
            modal.style.display = 'none';
            form.reset();
        }, 500);
    }
}


// ========================================== 
// MODALES DE SERVICIOS (ACTUALIZADO)
// ========================================== 

// Modal de contacto que abre desde el footer
function initFooterContactModal() {
    const modal = document.getElementById('footerContactModal');
    if (!modal) return;

    const openBtn = document.getElementById('open-contact-footer');
    const closeBtn = modal.querySelector('.close-button');
    const form = document.getElementById('footerContactForm');
    const sendBtn = document.getElementById('sendFooterEmail');

    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';

    if (!openBtn || !closeBtn || !form || !sendBtn) {
        console.warn('Elementos del modal footer no encontrados.');
        return;
    }

    openBtn.addEventListener('click', function(e) {
        e.preventDefault();
        modal.style.display = 'block';
    });

    closeBtn.addEventListener('click', () => modal.style.display = 'none');

    window.addEventListener('click', event => {
        if (event.target == modal) modal.style.display = 'none';
    });

    function getData() {
        const name = document.getElementById('footerName').value.trim();
        const email = document.getElementById('footerEmail').value.trim();
        const message = document.getElementById('footerMessage').value.trim();
        if (!name || !email || !message) {
            showNotification('Por favor, rellena todos los campos.', 'error');
            return null;
        }
        if (!isValidEmail(email)) {
            showNotification('Introduce un email válido.', 'error');
            return null;
        }
        return { name, email, message };
    }

    // Obtener botones separados
    const sendWhatsappBtn = document.getElementById('sendFooterWhatsapp');
    const sendTelegramBtn = document.getElementById('sendFooterTelegram');
    const sendEmailBtn = document.getElementById('sendFooterEmail');

    // Datos de contacto
    const phone = '34632634363';
    const telegramUser = 'Pacovalverde';

    if (sendWhatsappBtn) {
        sendWhatsappBtn.addEventListener('click', () => {
            const data = getData();
            if (!data) return;
            const text = `¡Hola! 👋 Te contacto desde la web.\nNombre: ${data.name}\nEmail: ${data.email}\nMensaje: ${data.message}`;
            const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
            window.open(url, '_blank').focus();
            showNotification('Te llevo a WhatsApp...', 'success');
            setTimeout(() => { modal.style.display = 'none'; form.reset(); }, 500);
        });
    }

    if (sendTelegramBtn) {
        sendTelegramBtn.addEventListener('click', () => {
            const data = getData();
            if (!data) return;
            const text = `¡Hola! 👋 Te contacto desde la web.\nNombre: ${data.name}\nEmail: ${data.email}\nMensaje: ${data.message}`;
            const url = `https://t.me/${telegramUser}?text=${encodeURIComponent(text)}`;
            window.open(url, '_blank').focus();
            showNotification('Te llevo a Telegram...', 'success');
            setTimeout(() => { modal.style.display = 'none'; form.reset(); }, 500);
        });
    }

    if (sendEmailBtn) {
        sendEmailBtn.addEventListener('click', () => {
            const data = getData();
            if (!data) return;
            const subject = `Contacto desde la web: ${data.name}`;
            const body = `Nombre: ${data.name}\nEmail: ${data.email}\n\nMensaje:\n${data.message}`;
            const url = `mailto:${emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
            window.location.href = url;
            showNotification('Abriendo cliente de correo...', 'success');
            setTimeout(() => { modal.style.display = 'none'; form.reset(); }, 500);
        });
    }
}

function initServiciosModals() {
    const phone = '34632634363';
    const telegramUser = 'Pacovalverde';
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';

    // 1. Análisis Nutricional
    setupServiceModal(
        'nutricionModal',
        ['open-nutricion-modal', 'open-nutricion-modal-2', 'open-nutricion-modal-cta', 'open-nutricion-modal-menu'],
        'nutricionForm',
        'Análisis Nutricional Gratuito',
        { phone, telegramUser, emailAddress },
        'nutricion'
    );

    // 2. Planes Personalizados
    setupServiceModal(
        'planesModal',
        ['open-planes-modal', 'open-planes-modal-2', 'open-planes-modal-menu'],
        'planesForm',
        'Planes Personalizados',
        { phone, telegramUser, emailAddress },
        'planes'
    );

    // 3. Coaching Online
    setupServiceModal(
        'coachingModal',
        ['open-coaching-modal', 'open-coaching-modal-2', 'open-coaching-modal-menu'],
        'coachingForm',
        'Coaching Online',
        { phone, telegramUser, emailAddress },
        'coaching'
    );
    
    // 4. Mentoría Personalizada
    setupServiceModal(
        'mentoriaModal',
        ['open-mentoria-modal', 'open-mentoria-modal-2', 'open-mentoria-modal-menu'],
        'mentoriaForm',
        'Mentoría Personalizada',
        { phone, telegramUser, emailAddress },
        'mentoria'
    );
}

// ========================================== 
// MODALES DE APÓYANOS (COLABORAR Y ALIANZAS)
// ========================================== 

function initApoyanosModals() {
    const phone = '34632634363';
    const telegramUser = 'Pacovalverde';
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';

    // 1. ¿Quieres Colaborar?
    setupServiceModal(
        'colaborarModal',
        ['open-colaborar-modal'],
        'colaborarForm',
        'Colaboración',
        { phone, telegramUser, emailAddress },
        'colaborar'
    );

    // 2. Alianzas Estratégicas
    setupServiceModal(
        'alianzasModal',
        ['open-alianzas-modal'],
        'alianzasForm',
        'Alianzas Estratégicas',
        { phone, telegramUser, emailAddress },
        'alianzas'
    );
}

// ========================================== 
// MODAL DE CONTACTO DIRECTO
// ========================================== 

function initContactDirectoModal() {
    const phone = '34632634363';
    const telegramUser = 'Pacovalverde';
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';

    // Contacto Directo
    setupServiceModal(
        'contactDirectoModal',
        ['open-contact-directo-modal', 'open-contact-modal', 'open-contact-modal-menu'],
        'contactDirectoForm',
        'Mensaje de Contacto',
        { phone, telegramUser, emailAddress },
        'contactDirecto'
    );
}

/**
 * Función auxiliar REFACTORIZADA para inicializar CUALQUIER modal de servicio con múltiples opciones de contacto.
 * @param {string} modalId - ID del elemento modal.
 * @param {string[]} openBtnIds - IDs de los botones que abren el modal.
 * @param {string} formId - ID del formulario.
 * @param {string} serviceTitle - Título del servicio para los mensajes.
 * @param {object} contact - Objeto con { phone, telegramUser, emailAddress }.
 * @param {string} formSuffix - Sufijo único para los IDs de los botones (ej. 'nutricion').
 */
function setupServiceModal(modalId, openBtnIds, formId, serviceTitle, contact, formSuffix) {
    const modal = document.getElementById(modalId);
    const form = document.getElementById(formId);

    if (!modal || !form) {
        console.error(`Elementos no encontrados para el modal: ${modalId}`);
        return;
    }

    const closeBtn = modal.querySelector('.close-button');
    const sendWhatsappBtn = document.getElementById(`sendWhatsapp-${formSuffix}`);
    const sendTelegramBtn = document.getElementById(`sendTelegram-${formSuffix}`);
    const sendEmailBtn = document.getElementById(`sendEmail-${formSuffix}`);

    if (!sendWhatsappBtn || !sendTelegramBtn || !sendEmailBtn) {
        console.error(`Botones de acción no encontrados para el form: ${formId}`);
        return;
    }

    // Abrir modal
    openBtnIds.forEach(btnId => {
        const openBtn = document.getElementById(btnId);
        if (openBtn) {
            openBtn.addEventListener('click', e => {
                e.preventDefault();
                modal.style.display = 'block';
            });
        }
    });

    // Cerrar modal
    if (closeBtn) {
        closeBtn.addEventListener('click', () => modal.style.display = 'none');
    }
    window.addEventListener('click', event => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Función para obtener y validar datos
    function getValidatedData() {
        const name = form.querySelector('input[name="name"]').value.trim();
        const email = form.querySelector('input[name="email"]').value.trim();
        const messageInput = form.querySelector('textarea[name="message"]');
        const message = messageInput ? messageInput.value.trim() : '';
        const isMessageRequired = formId === 'mentoriaForm';

        if (!name || !email || (isMessageRequired && !message)) {
            showNotification('Por favor, rellena todos los campos obligatorios.', 'error');
            return null;
        }
        if (!isValidEmail(email)) {
            showNotification('Por favor, introduce un email válido.', 'error');
            return null;
        }
        return { name, email, message };
    }
    
    // Lógica de envío
    sendWhatsappBtn.addEventListener('click', function() {
        const data = getValidatedData();
        if (!data) return;

        let whatsappText = `¡Hola! 👋 Te contacto desde la web para solicitar información sobre *${serviceTitle}*.

*Nombre:* ${data.name}
*Email:* ${data.email}`;
        if (data.message) whatsappText += `\n*Mensaje:* ${data.message}`;

        const url = `https://wa.me/${contact.phone}?text=${encodeURIComponent(whatsappText)}`;
        window.open(url, '_blank').focus();
        showNotification('¡Gracias! Serás redirigido a WhatsApp.', 'success');
        cleanup();
    });

    sendTelegramBtn.addEventListener('click', function() {
        const data = getValidatedData();
        if (!data) return;

        let telegramText = `¡Hola! 👋 Te contacto desde la web para ${serviceTitle}.

Nombre: ${data.name}
Email: ${data.email}`;
        if (data.message) telegramText += `\nMensaje: ${data.message}`;

        const url = `https://t.me/${contact.telegramUser}?text=${encodeURIComponent(telegramText)}`;
        window.open(url, '_blank').focus();
        showNotification('¡Gracias! Serás redirigido a Telegram.', 'success');
        cleanup();
    });

    sendEmailBtn.addEventListener('click', function() {
        const data = getValidatedData();
        if (!data) return;

        const subject = `Info sobre ${serviceTitle} - ${data.name}`;
        let body = `Hola,
Has recibido una solicitud de información sobre ${serviceTitle}.

Nombre: ${data.name}
Email: ${data.email}`;
        if (data.message) body += `\n\nMensaje:\n${data.message}`;
        body += `\n\n---
Enviado desde el formulario de Healthy & Happy Valverde.`;

        const url = `mailto:${contact.emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.location.href = url;
        showNotification('¡Gracias! Abriendo tu cliente de email.', 'success');
        cleanup();
    });

    // Limpiar y cerrar
    function cleanup() {
        setTimeout(() => {
            modal.style.display = 'none';
            form.reset();
        }, 500);
    }
}



// ========================================== 
// FUNCIONES AUXILIARES
// ========================================== 

// Agregar estilos dinámicos para notificaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes slideOutRight {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);

// ========================================== 
// SCROLL EFFECT EN HEADER
// ========================================== 

window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (window.scrollY > 50) {
        header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.15)';
    } else {
        header.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)';
    }
});

// ========================================== 
// CONTADOR (Opcional - para estatísticas)
// ========================================== 

function animateCounter(element, targetValue, duration = 2000) {
    let currentValue = 0;
    const increment = targetValue / (duration / 16); // 60fps

    const updateCounter = () => {
        currentValue += increment;
        if (currentValue < targetValue) {
            element.textContent = Math.floor(currentValue);
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = targetValue;
        }
    };

    updateCounter();
}

// ========================================== 
// TRACKING BÁSICO DE EVENTOS
// ========================================== 

function trackEvent(eventName, eventData = {}) {
    console.log(`Evento: ${eventName}`, eventData);
    // Aquí puedes integrar Google Analytics u otro servicio
}

// Rastrear clics en botones principales
document.querySelectorAll('.btn-primary').forEach(btn => {
    btn.addEventListener('click', function() {
        trackEvent('button_click', { buttonText: this.textContent });
    });
});

// ========================================== 
// SCROLL TOP (Volver al inicio)
// ========================================== 

function initScrollTop() {
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    
    if (scrollTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                scrollTopBtn.style.display = 'block';
            } else {
                scrollTopBtn.style.display = 'none';
            }
        });

        scrollTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

initScrollTop();

// ========================================== 
// LAZY LOADING DE IMÁGENES (Opcional)
// ========================================== 

if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
}

/**
 * MODAL PARA PRE-ORDEN DEL LIBRO
 */
function initPreorderModal() {
    const phone = '34632634363';
    const telegramUser = 'Pacovalverde';
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';

    // Pre-orden del libro
    setupServiceModal(
        'preorderModal',
        ['open-preorder-modal', 'open-preorder-modal-cta', 'open-preorder-modal-menu'],
        'preorderForm',
        'Pre-Orden del Libro "El Método Healthy"',
        { phone, telegramUser, emailAddress },
        'preorder'
    );
}

// ========================================== 
// CARRUSEL DE TESTIMONIOS
// ========================================== 
function initTestimonialSlider() {
    const container = document.querySelector('.testimonials-container');
    if (!container) return;

    const track = container.querySelector('.testimonials-track');
    const prevBtn = container.querySelector('#prev-testimonial');
    const nextBtn = container.querySelector('#next-testimonial');
    
    if (!track || !prevBtn || !nextBtn) return;
    
    const cards = Array.from(track.children);
    if (cards.length === 0) return;

    // Duplicar las tarjetas una vez más en JS para asegurar un bucle perfecto
    // Esto es más robusto que depender solo del HTML
    cards.forEach(card => {
        track.appendChild(card.cloneNode(true));
    });

    const allCards = Array.from(track.children);
    const originalCardCount = allCards.length / 2;
    let cardWidth;
    let currentIndex = 0;
    let isTransitioning = false;
    let autoScrollInterval;

    function setupSlider() {
        // Asegurarse de que el ancho de la tarjeta es correcto
        cardWidth = allCards[0].offsetWidth + 20; // Ancho de tarjeta + margen (2*10px)
        
        // Ajustar el ancho total del track
        track.style.width = `${cardWidth * allCards.length}px`;

        // Posición inicial
        track.style.transition = 'none'; // Sin animación para el posicionamiento inicial
        currentIndex = originalCardCount / 2; // Empezar en medio del primer set de clones
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;

        // Re-activar transiciones
        setTimeout(() => {
            track.style.transition = 'transform 0.5s ease-in-out';
        }, 50);

        // Iniciar el auto-scroll
        startAutoScroll();
    }

    function moveToNext() {
        if (isTransitioning) return;
        isTransitioning = true;
        
        currentIndex++;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    function moveToPrev() {
        if (isTransitioning) return;
        isTransitioning = true;

        currentIndex--;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    track.addEventListener('transitionend', () => {
        isTransitioning = false;
        
        // Salto al final si llegamos al principio del set
        if (currentIndex <= 0) {
            track.style.transition = 'none';
            currentIndex = originalCardCount;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
        
        // Salto al principio si llegamos al final del set
        if (currentIndex >= originalCardCount + (originalCardCount / 2)) {
             track.style.transition = 'none';
            currentIndex = originalCardCount / 2;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
    });

    const startAutoScroll = () => {
        stopAutoScroll(); // Limpiar cualquier intervalo anterior
        autoScrollInterval = setInterval(moveToNext, 4000);
    };

    const stopAutoScroll = () => {
        clearInterval(autoScrollInterval);
    };
    
    nextBtn.addEventListener('click', () => {
        stopAutoScroll();
        moveToNext();
        startAutoScroll();
    });

    prevBtn.addEventListener('click', () => {
        stopAutoScroll();
        moveToPrev();
        startAutoScroll();
    });

    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);

    // Usar window.onload para asegurar que todas las imágenes y estilos estén cargados
    window.addEventListener('load', setupSlider);
    // Un fallback por si 'load' ya ocurrió
    if (document.readyState === 'complete') {
        setupSlider();
    }
}

// ========================================== 
// CARRUSEL DE TRANSFORMACIONES (NUEVO)
// ========================================== 
function initTransformationCarousel() {
    const carousel = document.querySelector('.transformation-gallery');
    if (!carousel) return;

    const track = carousel.querySelector('.carousel-track');
    const trackContainer = carousel.querySelector('.carousel-track-container');
    const slides = Array.from(track.children);
    const nextButton = carousel.querySelector('#next-slide');
    const prevButton = carousel.querySelector('#prev-slide');
    const dotsNav = carousel.querySelector('.carousel-dots');

    if (!track || !trackContainer || slides.length === 0 || !nextButton || !prevButton || !dotsNav) {
        console.warn('Carousel elements not found');
        return;
    }

    let slideWidth = 0;
    let currentIndex = 0;
    let autoScrollInterval;

    // Función para obtener el ancho correctamente
    const updateSlideWidth = () => {
        slideWidth = trackContainer.offsetWidth || slides[0].offsetWidth;
    };

    // Inicializar ancho después de que las imágenes carguen
    if (slides[0] && slides[0].querySelector('img')) {
        const img = slides[0].querySelector('img');
        if (img.complete) {
            // La imagen ya está cargada
            updateSlideWidth();
        } else {
            // Esperar a que cargue
            img.addEventListener('load', updateSlideWidth);
        }
    }
    
    // Fallback: obtener ancho con pequeño delay
    setTimeout(updateSlideWidth, 100);

    // Recalcular ancho en responsive
    window.addEventListener('resize', updateSlideWidth);

    // Create dots
    slides.forEach((slide, index) => {
        const dot = document.createElement('button');
        dot.classList.add('carousel-dot');
        if (index === 0) dot.classList.add('active');
        dotsNav.appendChild(dot);

        dot.addEventListener('click', e => {
            moveToSlide(index);
            stopAutoScroll();
            startAutoScroll();
        });
    });

    const dots = Array.from(dotsNav.children);

    const moveToSlide = (targetIndex) => {
        if (slideWidth === 0) updateSlideWidth();
        track.style.transform = 'translateX(-' + (slideWidth * targetIndex) + 'px)';
        
        // Update dots
        dots[currentIndex].classList.remove('active');
        dots[targetIndex].classList.add('active');
        
        currentIndex = targetIndex;
    };

    // When clicking left, move slides to the right
    prevButton.addEventListener('click', e => {
        let newIndex = currentIndex - 1;
        if (newIndex < 0) {
            newIndex = slides.length - 1; // Loop to the end
        }
        moveToSlide(newIndex);
        stopAutoScroll();
        startAutoScroll();
    });

    // When clicking right, move slides to the left
    nextButton.addEventListener('click', e => {
        let newIndex = currentIndex + 1;
        if (newIndex >= slides.length) {
            newIndex = 0; // Loop to the start
        }
        moveToSlide(newIndex);
        stopAutoScroll();
        startAutoScroll();
    });

    const startAutoScroll = () => {
        stopAutoScroll();
        autoScrollInterval = setInterval(() => {
            let newIndex = currentIndex + 1;
            if (newIndex >= slides.length) {
                newIndex = 0;
            }
            moveToSlide(newIndex);
        }, 5000); // Change slide every 5 seconds
    };

    const stopAutoScroll = () => {
        clearInterval(autoScrollInterval);
    };

    // Recalculate width on resize
    window.addEventListener('resize', () => {
        const newSlideWidth = slides[0].getBoundingClientRect().width;
        // setSlidePosition(slides, i); // Not needed with flex
        track.style.transition = 'none'; // Disable transition for instant adjustment
        track.style.transform = 'translateX(-' + (newSlideWidth * currentIndex) + 'px)';
        setTimeout(() => {
            track.style.transition = 'transform 0.5s ease-in-out';
        }, 50);
    });

    startAutoScroll();
}

/* ==========================================
   COUNTDOWN TIMER - OFERTA LIMITADA 3 MESES
   ========================================== */

function initCountdownTimer() {
    // Configurar fecha de término: 3 meses desde hoy
    const targetDate = new Date();
    targetDate.setMonth(targetDate.getMonth() + 3);
    
    // Función para actualizar el countdown
    function updateCountdown() {
        const now = new Date().getTime();
        const distance = targetDate.getTime() - now;
        
        // Calcular tiempo
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Actualizar elementos del DOM
        const daysElement = document.getElementById('days');
        const hoursElement = document.getElementById('hours');
        const minutesElement = document.getElementById('minutes');
        const secondsElement = document.getElementById('seconds');
        
        if (daysElement) daysElement.textContent = String(days).padStart(2, '0');
        if (hoursElement) hoursElement.textContent = String(hours).padStart(2, '0');
        if (minutesElement) minutesElement.textContent = String(minutes).padStart(2, '0');
        if (secondsElement) secondsElement.textContent = String(seconds).padStart(2, '0');
        
        // Si el countdown llegó a 0
        if (distance < 0) {
            const countdownSection = document.querySelector('.countdown-timer-section');
            if (countdownSection) {
                countdownSection.innerHTML = `
                    <div class="countdown-container">
                        <div class="countdown-content">
                            <div class="countdown-header">
                                <h2 class="countdown-title">¡La Oferta ha Terminado!</h2>
                                <p class="countdown-subtitle">Gracias por tu interés en "El Método Healthy"</p>
                                <a href="#libro" class="btn btn-primary" style="margin-top: 20px;">Ver Precio Regular</a>
                            </div>
                        </div>
                    </div>
                `;
            }
        }
    }
    
    // Actualizar cada segundo
    updateCountdown();
    setInterval(updateCountdown, 1000);
    
    // Hacer que el botón del countdown abra el mismo modal que el libro
    const countdownBtn = document.getElementById('open-preorder-countdown');
    if (countdownBtn) {
        countdownBtn.addEventListener('click', function(e) {
            e.preventDefault();
            // Reutilizar el modal existente de preorder
            const preorderModal = document.getElementById('preorderModal');
            if (preorderModal) {
                preorderModal.style.display = 'flex';
            }
        });
    }
}

console.log('🎉 Healthy & Happy Valverde - Script cargado correctamente');
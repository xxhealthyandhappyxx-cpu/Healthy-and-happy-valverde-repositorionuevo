/* ========================================== 
   COACH PAGE - JAVASCRIPT
   Funcionalidad específica de página coach
   ========================================== */

document.addEventListener('DOMContentLoaded', function() {
    initCoachTestimonialSlider();
    initCoachAnimations();
    initServiceModals();
    initCTAModals();
    initModalHandlers();
    initSesionGratuitaForm();
});

// ========================================== 
// MANEJADOR DE MODALES DE SERVICIOS
// ========================================== 

function initServiceModals() {
    const serviceButtons = document.querySelectorAll('.service-link-btn');
    
    serviceButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modalType = this.getAttribute('data-modal');
            openServiceModal(modalType);
        });
    });
}

function openServiceModal(type) {
    const modalMap = {
        'nutricion': 'nutricionModal',
        'planes': 'planesModal',
        'coaching': 'coachingModal',
        'mentoria': 'mentoriaModal'
    };
    
    const modalId = modalMap[type];
    if (modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }
}

// ========================================== 
// MANEJADOR DE MODALES CTA (HERO Y STRONG)
// ========================================== 

function initCTAModals() {
    // Handler para botón "Empieza Gratis Hoy" en hero section
    const sesionGratuitaBtn = document.getElementById('open-sesion-gratuita-modal');
    if (sesionGratuitaBtn) {
        sesionGratuitaBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('sesionGratuitaModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }

    // Handler para botón "Sesión Gratuita" en hero section (antiguo)
    const mentoriaBtnHero = document.getElementById('open-mentoria-modal-hero');
    if (mentoriaBtnHero) {
        mentoriaBtnHero.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('mentoriaModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }

    // Handler para botón "Reservar Sesión Gratuita" en sección CTA
    const mentoriaBtn = document.getElementById('open-mentoria-modal');
    if (mentoriaBtn) {
        mentoriaBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('mentoriaModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }

    // Handler para botón "Contactar Ahora" en sección CTA
    const contactBtn = document.getElementById('open-contact-modal');
    if (contactBtn) {
        contactBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('footerContactModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }

    // Handler para botón "Reservar Sesión Gratuita" en sección de impacto
    const mentoriaBtnImpact = document.getElementById('open-mentoria-modal-impact');
    if (mentoriaBtnImpact) {
        mentoriaBtnImpact.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('mentoriaModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }

    // Handler para botón "Contactar Ahora" en sección de impacto
    const contactBtnImpact = document.getElementById('open-contact-modal-impact');
    if (contactBtnImpact) {
        contactBtnImpact.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const modal = document.getElementById('footerContactModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        });
    }
}

// ========================================== 
// MANEJADORES DE MODALES GENÉRICOS
// ========================================== 

function initModalHandlers() {
    const closeButtons = document.querySelectorAll('.close-button');
    const modals = document.querySelectorAll('.modal');
    
    closeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    });
    
    modals.forEach(modal => {
        modal.addEventListener('click', function(event) {
            // Solo cerrar si se hace click en el background del modal, no en el contenido
            if (event.target === this) {
                this.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    });
}

// ========================================== 
// TESTIMONIAL SLIDER PARA PÁGINA COACH
// ========================================== 

function initCoachTestimonialSlider() {
    const container = document.querySelector('.testimonials-container');
    if (!container) return;

    const track = container.querySelector('.testimonials-track');
    const prevBtn = container.querySelector('#prev-testimonial');
    const nextBtn = container.querySelector('#next-testimonial');
    
    if (!track || !prevBtn || !nextBtn) return;
    
    const cards = Array.from(track.children);
    if (cards.length === 0) return;

    // Duplicar las tarjetas una vez más en JS para asegurar un bucle perfecto
    cards.forEach(card => {
        track.appendChild(card.cloneNode(true));
    });

    const allCards = Array.from(track.children);
    const originalCardCount = allCards.length / 2;
    let cardWidth;
    let currentIndex = 0;
    let isTransitioning = false;
    let autoScrollInterval;

    function setupSlider() {
        cardWidth = allCards[0].offsetWidth + 20; // Ancho de tarjeta + margen
        track.style.width = `${cardWidth * allCards.length}px`;
        track.style.transition = 'none';
        currentIndex = originalCardCount / 2;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;

        setTimeout(() => {
            track.style.transition = 'transform 0.5s ease-in-out';
        }, 50);

        startAutoScroll();
    }

    function moveToNext() {
        if (isTransitioning) return;
        isTransitioning = true;
        
        currentIndex++;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    function moveToPrev() {
        if (isTransitioning) return;
        isTransitioning = true;

        currentIndex--;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    track.addEventListener('transitionend', () => {
        isTransitioning = false;
        
        if (currentIndex <= 0) {
            track.style.transition = 'none';
            currentIndex = originalCardCount;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
        
        if (currentIndex >= originalCardCount + (originalCardCount / 2)) {
            track.style.transition = 'none';
            currentIndex = originalCardCount / 2;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
    });

    const startAutoScroll = () => {
        stopAutoScroll();
        autoScrollInterval = setInterval(moveToNext, 4000);
    };

    const stopAutoScroll = () => {
        clearInterval(autoScrollInterval);
    };
    
    nextBtn.addEventListener('click', () => {
        stopAutoScroll();
        moveToNext();
        startAutoScroll();
    });

    prevBtn.addEventListener('click', () => {
        stopAutoScroll();
        moveToPrev();
        startAutoScroll();
    });

    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);

    setupSlider();
}

// ========================================== 
// ANIMACIONES AL SCROLL
// ========================================== 

function initCoachAnimations() {
    const animatedElements = document.querySelectorAll(
        '.about-coach-text, .service-card-simple, .why-choose-item, .transformation-item, .testimonial-card'
    );

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.animation = 'fadeInUp 0.6s ease-out forwards';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach((el) => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}

// ========================================== 
// MANEJADOR DEL FORMULARIO DE SESIÓN GRATUITA
// ========================================== 

function initSesionGratuitaForm() {
    // Contacto de Francisco
    const whatsappNumber = '34649661199';
    const telegramUser = 'Pacovalverde';
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com';
    
    // Botones de WhatsApp
    const whatsappBtns = document.querySelectorAll('[id*="sendWhatsapp-sesion"]');
    whatsappBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const form = document.getElementById('sesionGratuitaForm');
            if (!form) return;
            
            const name = form.querySelector('#sesionName')?.value.trim();
            const email = form.querySelector('#sesionEmail')?.value.trim();
            const phone = form.querySelector('#sesionPhone')?.value.trim();
            const objetivo = form.querySelector('#sesionObjectivo')?.value.trim();
            const message = form.querySelector('#sesionMensaje')?.value.trim();
            
            if (!name || !email || !phone || !objetivo || !message) {
                alert('Por favor, rellena todos los campos.');
                return;
            }
            
            const whatsappMessage = `Hola Francisco, me gustaría reservar una sesión gratuita.%0A%0A*Nombre:* ${name}%0A*Email:* ${email}%0A*Teléfono:* ${phone}%0A*Objetivo:* ${objetivo}%0A*Situación:* ${message}`;
            window.open(`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`, '_blank');
            
            form.reset();
            document.getElementById('sesionGratuitaModal').style.display = 'none';
        });
    });
    
    // Botones de Telegram
    const telegramBtns = document.querySelectorAll('[id*="sendTelegram-sesion"]');
    telegramBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const form = document.getElementById('sesionGratuitaForm');
            if (!form) return;
            
            const name = form.querySelector('#sesionName')?.value.trim();
            const email = form.querySelector('#sesionEmail')?.value.trim();
            const phone = form.querySelector('#sesionPhone')?.value.trim();
            const objetivo = form.querySelector('#sesionObjectivo')?.value.trim();
            const message = form.querySelector('#sesionMensaje')?.value.trim();
            
            if (!name || !email || !phone || !objetivo || !message) {
                alert('Por favor, rellena todos los campos.');
                return;
            }
            
            const telegramMessage = `Hola Francisco, me gustaría reservar una sesión gratuita.%0A%0AResponde a estos datos:%0ANombre: ${name}%0AEmail: ${email}%0ATeléfono: ${phone}%0AObjetivo: ${objetivo}%0ASituación: ${message}`;
            window.open(`https://t.me/${telegramUser}?text=${telegramMessage}`, '_blank');
            
            form.reset();
            document.getElementById('sesionGratuitaModal').style.display = 'none';
        });
    });
    
    // Botones de Email
    const emailBtns = document.querySelectorAll('[id*="sendEmail-sesion"]');
    emailBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const form = document.getElementById('sesionGratuitaForm');
            if (!form) return;
            
            const name = form.querySelector('#sesionName')?.value.trim();
            const email = form.querySelector('#sesionEmail')?.value.trim();
            const phone = form.querySelector('#sesionPhone')?.value.trim();
            const objetivo = form.querySelector('#sesionObjectivo')?.value.trim();
            const message = form.querySelector('#sesionMensaje')?.value.trim();
            
            if (!name || !email || !phone || !objetivo || !message) {
                alert('Por favor, rellena todos los campos.');
                return;
            }
            
            const subject = encodeURIComponent('Solicitud de Sesión Gratuita');
            const body = encodeURIComponent(`Hola Francisco,\n\nMe gustaría reservar una sesión gratuita contigo.\n\nMis datos:\nNombre: ${name}\nEmail: ${email}\nTeléfono: ${phone}\nObjetivo: ${objetivo}\n\nMi situación:\n${message}`);
            
            window.location.href = `mailto:${emailAddress}?subject=${subject}&body=${body}`;
            
            form.reset();
            document.getElementById('sesionGratuitaModal').style.display = 'none';
        });
    });
}

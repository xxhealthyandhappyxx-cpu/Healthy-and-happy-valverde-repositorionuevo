# 🛠️ GUÍA RÁPIDA DE MANTENIMIENTO - PÁGINA COACH

## Archivos Modificados
- `pagina.coach.html` - Sección HERO (líneas 130-165)
- `css/coach-style.css` - Nuevos estilos CSS

---

## 🎨 Si Necesitas Cambios Futuros

### Cambiar Color del Badge/Etiqueta
```css
/* Línea ~54 en coach-style.css */
.coach-badge {
    background: rgba(255, 255, 255, 0.2);  /* Cambiar opacidad */
    border: 1px solid rgba(255, 255, 255, 0.4);  /* Cambiar color borde */
}
```

### Cambiar Colores de los Botones
```css
/* Línea ~170 en coach-style.css */
.hero-coach-buttons .btn-primary {
    background: linear-gradient(135deg, #E53935, #C41E3A);  /* Cambiar colores */
}
```

### Cambiar Textos
```html
<!-- En pagina.coach.html -->
<span class="coach-badge">NUEVO TEXTO AQUÍ</span>
<h1>Nuevo Título</h1>
<p>Nuevo subtítulo</p>
<!-- etc. -->
```

### Cambiar Iconos
```html
<!-- Los iconos usan Font Awesome -->
<i class="fas fa-check-circle"></i>  <!-- Cambiar el nombre del icono -->
```

### Hacer el Hero Más Alto/Ancho
```css
/* Línea ~16 en coach-style.css */
.hero-coach {
    padding: 80px 20px;  /* Aumentar para más espacio vertical */
    min-height: 600px;   /* Aumentar altura mínima */
}
```

### Cambiar Velocidad de Animaciones
```css
/* Cambiar "0.3s" o "1s" a otra duración */
transition: all 0.3s ease;  /* 0.3s es la velocidad actual */
animation: fadeIn 1s ease-out 0.3s both;  /* 1s es la duración */
```

---

## 📱 Responsive: Puntos de Quiebre

```css
@media (max-width: 768px) { }   /* Tablet */
@media (max-width: 480px) { }   /* Móvil */
```

---

## 🎯 CTAs que Funcionan

Los botones ejecutan JavaScript:
- `id="open-mentoria-modal-hero"` - Abre el modal de mentoría
- `#servicios-coach` - Navega a esa sección

Puedes cambiar los `href` si necesitas otras acciones.

---

## 💾 Backup Recomendado

Antes de hacer cambios:
1. Copia `pagina.coach.html`
2. Copia `css/coach-style.css`
3. Guarda como `_backup_fecha.html` y `.css`

---

## 🔍 Verificación Rápida

Después de cambios:
1. Abre el archivo en navegador
2. Verifica en móvil (F12 → responsive)
3. Comprueba los botones funcionan
4. Revisa que las animaciones se vean bien

---

## 📞 Soporte

Si necesitas más cambios:
- Las clases CSS están bien documentadas
- Los IDs en HTML son claros
- Todo está estructurado de forma lógica
- Puedes buscar ".hero-coach" para encontrar la sección

---

**Última actualización:** 15 de enero de 2026

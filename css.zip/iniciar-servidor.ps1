#!/usr/bin/env pwsh
# Script para servir Healthy & Happy Valverde localmente
# Autor: Francisco Valverde
# Fecha: 29 de noviembre de 2025

Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "HEALTHY & HAPPY VALVERDE" -ForegroundColor Green
Write-Host "Servidor Local" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Verificar si Python está instalado
try {
    $pythonVersion = python --version 2>&1
    Write-Host "[✓] Python encontrado: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Python no está instalado" -ForegroundColor Red
    Write-Host ""
    Write-Host "Opción 1: Instala Python desde https://www.python.org/" -ForegroundColor Yellow
    Write-Host "Opción 2: Usa 'Live Server' en VS Code" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

Write-Host ""

# Ir al directorio actual
$currentDir = Get-Location
Write-Host "[✓] Directorio: $currentDir" -ForegroundColor Green
Write-Host ""

# Verificar que exista index-home.html
if (-not (Test-Path "index-home.html")) {
    Write-Host "[ERROR] No se encuentra index-home.html" -ForegroundColor Red
    Write-Host ""
    Write-Host "Por favor ejecuta este script desde la carpeta de Healthy & Happy Valverde" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

Write-Host "[✓] index-home.html encontrado" -ForegroundColor Green
Write-Host ""

# Puerto
$port = 8000

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "INICIANDO SERVIDOR LOCAL" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "🌐 URL Principal:" -ForegroundColor Cyan
Write-Host "   http://localhost:$port/index-home.html" -ForegroundColor Yellow
Write-Host ""
Write-Host "📂 Archivos disponibles:" -ForegroundColor Cyan
Write-Host "   - Página principal: http://localhost:$port/index-home.html" -ForegroundColor Yellow
Write-Host "   - Setup rápido: http://localhost:$port/SETUP_RAPIDO.html" -ForegroundColor Yellow
Write-Host ""
Write-Host "⚠️  Para detener el servidor: Presiona Ctrl+C" -ForegroundColor Yellow
Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Iniciar servidor Python
try {
    Write-Host "Abriendo navegador automáticamente..." -ForegroundColor Cyan
    Start-Sleep -Seconds 2
    
    # Intentar abrir en el navegador predeterminado
    try {
        Start-Process "http://localhost:$port/index-home.html"
    } catch {
        Write-Host "No se pudo abrir el navegador automáticamente." -ForegroundColor Yellow
        Write-Host "Por favor abre manualmente: http://localhost:$port/index-home.html" -ForegroundColor Yellow
    }
    
    Write-Host ""
    Write-Host "⏳ Iniciando servidor..." -ForegroundColor Cyan
    Write-Host ""
    
    # Iniciar el servidor
    python -m http.server $port
} catch {
    Write-Host ""
    Write-Host "[ERROR] No se pudo iniciar el servidor" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

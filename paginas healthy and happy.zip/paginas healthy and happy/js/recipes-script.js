/* ==========================================
   HEALTHY & HAPPY VALVERDE - RECETAS
   Scripts para funcionalidad de carrusel
   de testimonios y otros elementos dinámicos
   ========================================== */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar funciones de recetas
    initRecipeHamburgerMenu();
    initRecipeDropdowns();
    initRecipeTestimonialSlider();
    initRecipeFormModals();
    initSmoothScroll();
});

// ========================================== 
// MENÚ HAMBURGUESA PARA RECETAS
// ========================================== 

function initRecipeHamburgerMenu() {
    const hamburger = document.getElementById('hamburger');
    const navbar = document.getElementById('navbar');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navbar.classList.toggle('active');
            hamburger.classList.toggle('active');
        });

        // Cerrar menú al hacer clic en un link
        const navLinks = navbar.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navbar.classList.remove('active');
                hamburger.classList.remove('active');
            });
        });
    }
}

// ========================================== 
// DROPDOWNS PARA RECETAS
// ========================================== 

function initRecipeDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');

    dropdowns.forEach(dropdown => {
        const toggle = dropdown.querySelector('.dropdown-toggle');
        
        if (!toggle) return;

        toggle.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            }
        });
    });

    // Cerrar dropdowns al hacer clic fuera
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.dropdown')) {
            dropdowns.forEach(dropdown => {
                dropdown.classList.remove('active');
            });
        }
    });
}

// ========================================== 
// CARRUSEL DE TESTIMONIOS MEJORADO
// ========================================== 

function initRecipeTestimonialSlider() {
    const container = document.querySelector('.testimonials-container');
    if (!container) {
        console.warn('testimonials-container no encontrado');
        return;
    }

    const track = container.querySelector('.testimonials-track');
    const prevBtn = document.getElementById('prev-testimonial-recipes');
    const nextBtn = document.getElementById('next-testimonial-recipes');
    
    if (!track) {
        console.warn('testimonials-track no encontrado');
        return;
    }

    const cards = Array.from(track.children);
    if (cards.length === 0) {
        console.warn('No hay testimonial-cards');
        return;
    }

    console.log('Inicializando carrusel con', cards.length, 'tarjetas');

    // Duplicar las tarjetas en JS para crear un bucle infinito perfecto
    cards.forEach(card => {
        track.appendChild(card.cloneNode(true));
    });

    const allCards = Array.from(track.children);
    const originalCardCount = allCards.length / 2;
    let cardWidth;
    let currentIndex = 0;
    let isTransitioning = false;
    let autoScrollInterval;

    function setupSlider() {
        // Calcular ancho de tarjeta incluyendo márgenes
        const firstCard = allCards[0];
        const style = window.getComputedStyle(firstCard);
        const marginLeft = parseFloat(style.marginLeft);
        const marginRight = parseFloat(style.marginRight);
        cardWidth = firstCard.offsetWidth + marginLeft + marginRight;
        
        console.log('Ancho de tarjeta:', cardWidth, 'Total de tarjetas:', allCards.length);
        
        // Ajustar ancho total del track
        track.style.width = `${cardWidth * allCards.length}px`;

        // Posición inicial sin transiciones
        track.style.transition = 'none';
        currentIndex = originalCardCount / 2; // Empezar en medio del primer set
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;

        console.log('Índice inicial:', currentIndex, 'Posición:', currentIndex * cardWidth);

        // Re-activar transiciones después
        setTimeout(() => {
            track.style.transition = 'transform 0.5s ease-in-out';
        }, 50);

        // Iniciar auto-scroll
        startAutoScroll();
    }

    function moveToNext() {
        if (isTransitioning) return;
        isTransitioning = true;
        
        currentIndex++;
        console.log('Moviendo Next. Índice:', currentIndex);
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    function moveToPrev() {
        if (isTransitioning) return;
        isTransitioning = true;

        currentIndex--;
        console.log('Moviendo Prev. Índice:', currentIndex);
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }

    // Evento de transición para crear el bucle infinito sin saltos visibles
    track.addEventListener('transitionend', () => {
        isTransitioning = false;
        
        // Si llegamos al inicio, saltar al final del primer set
        if (currentIndex <= 0) {
            track.style.transition = 'none';
            currentIndex = originalCardCount;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            console.log('Saltando al final. Índice:', currentIndex);
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
        
        // Si llegamos al final, saltar al principio del segundo set
        if (currentIndex >= originalCardCount + (originalCardCount / 2)) {
            track.style.transition = 'none';
            currentIndex = originalCardCount / 2;
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
            console.log('Saltando al inicio. Índice:', currentIndex);
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease-in-out';
            }, 50);
        }
    });

    const startAutoScroll = () => {
        stopAutoScroll(); // Limpiar cualquier intervalo anterior
        console.log('Auto-scroll iniciado');
        autoScrollInterval = setInterval(() => {
            moveToPrev();
        }, 3000); // Mover hacia la derecha cada 3 segundos
    };

    const stopAutoScroll = () => {
        clearInterval(autoScrollInterval);
        console.log('Auto-scroll detenido');
    };
    
    // Botones de navegación
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            console.log('Clic en Next');
            stopAutoScroll();
            moveToNext();
            startAutoScroll();
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            console.log('Clic en Prev');
            stopAutoScroll();
            moveToPrev();
            startAutoScroll();
        });
    }

    // Pausar en hover, reanudar al salir
    container.addEventListener('mouseenter', () => {
        console.log('Mouse enter - pausando');
        stopAutoScroll();
    });
    container.addEventListener('mouseleave', () => {
        console.log('Mouse leave - reanudando');
        startAutoScroll();
    });

    // Usar window.onload para asegurar que todas las imágenes y estilos estén cargados
    const initWhenReady = () => {
        console.log('Iniciando slider...');
        setupSlider();
    };

    if (document.readyState === 'loading') {
        window.addEventListener('load', initWhenReady);
    } else {
        // El documento ya está completamente cargado
        setTimeout(initWhenReady, 100);
    }
}

// ========================================== 
// GESTIÓN DE MODALES DE FORMULARIOS
// ========================================== 

function initRecipeFormModals() {
    // Inicializar todos los modales de contacto
    initNutricionModal();
    initPlanesModal();
    initCoachingModal();
    initMentoriaModal();
    initFooterContactModalRecipes();
}

function initNutricionModal() {
    const modalId = 'nutricionModal';
    const openButtons = document.querySelectorAll('#open-nutricion-modal, #open-nutricion-modal-menu, #open-nutricion-modal-2, #open-nutricion-modal-cta');
    const modal = document.getElementById(modalId);
    
    if (!modal) return;

    const closeButton = modal.querySelector('.close-button');
    
    openButtons.forEach(button => {
        if (button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });
        }
    });
    
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // Gestionar envíos de formulario
    setupFormSendOptions(modalId);
}

function initPlanesModal() {
    const modalId = 'planesModal';
    const openButtons = document.querySelectorAll('#open-planes-modal, #open-planes-modal-menu, #open-planes-modal-2, #open-planes-modal-final');
    const modal = document.getElementById(modalId);
    
    if (!modal) {
        console.warn('Modal planesModal no encontrado');
        return;
    }

    const closeButton = modal.querySelector('.close-button');
    
    openButtons.forEach(button => {
        if (button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                console.log('Abriendo modal planes');
            });
        }
    });
    
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            console.log('Cerrando modal planes');
        });
    }

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    setupFormSendOptions(modalId);
}

function initCoachingModal() {
    const modalId = 'coachingModal';
    const openButtons = document.querySelectorAll('#open-coaching-modal, #open-coaching-modal-menu, #open-coaching-modal-2');
    const modal = document.getElementById(modalId);
    
    if (!modal) return;

    const closeButton = modal.querySelector('.close-button');
    
    openButtons.forEach(button => {
        if (button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });
        }
    });
    
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    setupFormSendOptions(modalId);
}

function initMentoriaModal() {
    const modalId = 'mentoriaModal';
    const openButtons = document.querySelectorAll('#open-mentoria-modal, #open-mentoria-modal-menu, #open-mentoria-modal-2');
    const modal = document.getElementById(modalId);
    
    if (!modal) return;

    const closeButton = modal.querySelector('.close-button');
    
    openButtons.forEach(button => {
        if (button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });
        }
    });
    
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    setupFormSendOptions(modalId);
}

function initFooterContactModalRecipes() {
    const modal = document.getElementById('footerContactModal');
    if (!modal) return;

    const closeButton = modal.querySelector('.close-button');
    const openButton = document.getElementById('open-contact-footer');
    
    if (openButton) {
        openButton.addEventListener('click', function(e) {
            e.preventDefault();
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        });
    }
    
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    setupFormSendOptions('footerContactModal');
}

function setupFormSendOptions(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    // Detectar el tipo de formulario
    const form = modal.querySelector('form');
    if (!form) return;

    const formId = form.id;
    const whatsappBtn = modal.querySelector('[id*="sendWhatsapp"]');
    const telegramBtn = modal.querySelector('[id*="sendTelegram"]');
    const emailBtn = modal.querySelector('[id*="sendEmail"]');

    const phone = '34632634363'; // Número WhatsApp de Pacozom
    const telegramId = 'Pacovalverde'; // Usuario Telegram
    const emailAddress = 'xxhealthyandhappyxx@hotmail.com'; // Email

    if (whatsappBtn) {
        whatsappBtn.addEventListener('click', function() {
            const formData = new FormData(form);
            let message = `Hola Francisco, me gustaría:\n\n`;
            
            for (let [key, value] of formData.entries()) {
                if (value) {
                    message += `${key}: ${value}\n`;
                }
            }

            const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    if (telegramBtn) {
        telegramBtn.addEventListener('click', function() {
            const formData = new FormData(form);
            let message = `Hola Francisco, me gustaría:\n\n`;
            
            for (let [key, value] of formData.entries()) {
                if (value) {
                    message += `${key}: ${value}\n`;
                }
            }

            const telegramUrl = `https://t.me/${telegramId}?text=${encodeURIComponent(message)}`;
            window.open(telegramUrl, '_blank');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    if (emailBtn) {
        emailBtn.addEventListener('click', function() {
            const formData = new FormData(form);
            let emailBody = ``;
            
            for (let [key, value] of formData.entries()) {
                if (value) {
                    emailBody += `${key}: ${value}\n`;
                }
            }

            const emailUrl = `mailto:${emailAddress}?body=${encodeURIComponent(emailBody)}`;
            window.location.href = emailUrl;
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }
}

// ========================================== 
// SCROLL SUAVE
// ========================================== 

function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href === '#') return;

            e.preventDefault();
            const target = document.querySelector(href);
            
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

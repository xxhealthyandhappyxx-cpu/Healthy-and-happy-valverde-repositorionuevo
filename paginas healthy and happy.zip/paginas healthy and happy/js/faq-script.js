document.addEventListener('DOMContentLoaded', function() {
    
    // Lógica para el acordeón de preguntas
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const questionButton = item.querySelector('.faq-question');

        if (questionButton) {
            questionButton.addEventListener('click', () => {
                const isActive = item.classList.contains('active');

                // Si quieres que solo una pregunta esté abierta a la vez, descomenta este bloque
                // faqItems.forEach(otherItem => {
                //     if (otherItem !== item) {
                //         otherItem.classList.remove('active');
                //     }
                // });

                // Alternar la clase 'active' en el item clickeado
                item.classList.toggle('active');
            });
        }
    });

    // Lógica para la barra de búsqueda de preguntas
    const searchInput = document.getElementById('faq-search');

    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = searchInput.value.toLowerCase().trim();

            faqItems.forEach(item => {
                const questionText = item.querySelector('.faq-question span').textContent.toLowerCase();
                
                if (questionText.includes(searchTerm)) {
                    item.classList.remove('hidden');
                } else {
                    item.classList.add('hidden');
                }
            });
        });
    }
});

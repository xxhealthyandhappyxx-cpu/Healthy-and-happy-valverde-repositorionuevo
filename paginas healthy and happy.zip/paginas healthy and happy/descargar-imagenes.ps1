#!/usr/bin/env pwsh
# Script para descargar imágenes de Healthy & Happy Valverde WordPress

$destinoFolder = "$PSScriptRoot\images"

# Crear carpeta si no existe
if (-not (Test-Path $destinoFolder)) {
    New-Item -ItemType Directory -Path $destinoFolder | Out-Null
}

Write-Host "Descargando imágenes de tu WordPress..." -ForegroundColor Green
Write-Host ""

# URL 1: Favicon
$url1 = "https://healthyandhappyvalverde.wordpress.com/wp-content/uploads/2024/09/healthy-happy-valverde-salud-y-bienestar-modified.png"
$output1 = Join-Path $destinoFolder "logo-favicon.png"

try {
    Write-Host "Descargando favicon..." -ForegroundColor Cyan
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $url1 -OutFile $output1 -ErrorAction Stop
    Write-Host "✓ Favicon descargado: $output1" -ForegroundColor Green
} catch {
    Write-Host "✗ Error descargando favicon: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# URL 2: Portada del Podcast
$url2 = "https://healthyandhappyvalverde.wordpress.com/wp-content/uploads/2024/11/transformacion-fitness-healthy-and-happy-valverde-francisco-valverde.png"
$output2 = Join-Path $destinoFolder "podcast-portada.png"

try {
    Write-Host "Descargando portada del Podcast..." -ForegroundColor Cyan
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $url2 -OutFile $output2 -ErrorAction Stop
    Write-Host "✓ Portada descargada: $output2" -ForegroundColor Green
} catch {
    Write-Host "✗ Error descargando portada: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=================================" -ForegroundColor Green
Write-Host "Descarga completada!" -ForegroundColor Green
Write-Host "Imágenes guardadas en: $destinoFolder" -ForegroundColor Green
Write-Host "=================================" -ForegroundColor Green

# 🚀 GUÍA DE EXPANSIÓN Y MANTENIMIENTO DEL BLOG

## Para Aumentar el Número de Artículos

Tu blog está estructurado para crecer fácilmente. Aquí te muestro cómo añadir más artículos sin necesidad de reescribir código.

---

## 📝 CÓMO AÑADIR UN NUEVO ARTÍCULO

### PASO 1: Añade el Artículo en el HTML

En `blog.html`, dentro del `<div class="blog-grid">`, añade una nueva tarjeta:

```html
<!-- Card 16 - Tu Nuevo Artículo -->
<article class="blog-card" data-category="nutricion">
    <div class="blog-card-image"><i class="fas fa-carrot"></i></div>
    <div class="blog-card-content">
        <span class="blog-card-category">Nutrición</span>
        <h3 class="blog-card-title">Tu Título Impactante Aquí</h3>
        <p class="blog-card-excerpt">Tu descripción breve y seductora aquí...</p>
        <button class="blog-card-link open-article-btn" data-article="article-16">
            <i class="fas fa-arrow-right"></i> Más información
        </button>
    </div>
</article>
```

⚠️ **Importante:**
- El `data-category` debe ser uno de estos: `nutricion`, `fitness`, `bienestar`, `recetas`, `inspiracion`
- El `data-article` debe ser `article-16`, `article-17`, etc. (número único)

### PASO 2: Añade el Contenido en JavaScript

En `js/blog-script.js`, dentro de `articlesData`, añade:

```javascript
'article-16': {
    title: 'Tu Título Impactante Aquí',
    category: 'Nutrición',
    content: `
        <p>Tu introducción aquí...</p>
        
        <h3>Subtítulo 1</h3>
        <p>Contenido...</p>
        
        <div class="highlight">
            <strong>CONSEJO:</strong> Algo importante...
        </div>
        
        <h3>Subtítulo 2</h3>
        <ul>
            <li>Punto 1</li>
            <li>Punto 2</li>
        </ul>
    `
}
```

### PASO 3: Elige un Icono

En Font Awesome hay +7000 iconos. Reemplaza el icono en la tarjeta:

Ejemplos útiles:
```
Nutrición:      <i class="fas fa-apple-alt"></i>
                <i class="fas fa-leaf"></i>
                <i class="fas fa-utensils"></i>

Fitness:        <i class="fas fa-dumbbell"></i>
                <i class="fas fa-running"></i>
                <i class="fas fa-heart-pulse"></i>

Recetas:        <i class="fas fa-utensils"></i>
                <i class="fas fa-bowl-food"></i>
                <i class="fas fa-cake-candles"></i>

Bienestar:      <i class="fas fa-spa"></i>
                <i class="fas fa-meditation"></i>
                <i class="fas fa-moon"></i>

Inspiración:    <i class="fas fa-heart"></i>
                <i class="fas fa-rocket"></i>
                <i class="fas fa-star"></i>
```

Busca más en: https://fontawesome.com/icons

---

## 🔄 CÓMO MODIFICAR UN ARTÍCULO EXISTENTE

### Cambiar Solo la Tarjeta (Preview)

En `blog.html`, encuentra la tarjeta y cambia:
- `blog-card-title` - Título
- `blog-card-excerpt` - Descripción breve
- `blog-card-image i` - Icono

### Cambiar Solo el Contenido Modal

En `js/blog-script.js`, busca el objeto `article-X` y modifica solo el contenido dentro de `content: \`...\``

---

## 🎨 PERSONALIZACIÓN AVANZADA

### Cambiar Colores Globales

En `css/blog-style.css`, en la sección `:root` cambia:

```css
:root {
    --color-primary: #ff6b35;    /* Color botones y CTA */
    --color-secondary: #004e89;  /* Color títulos */
    --color-accent: #1dd1a1;     /* Acentos */
    --color-light: #f8f9fa;      /* Fondos claros */
    --color-dark: #1a1a1a;       /* Textos oscuros */
}
```

### Cambiar Estructura del Modal

En `js/blog-script.js`, busca esta sección:

```javascript
articleContent.innerHTML = `
    <h2>${article.title}</h2>
    <p style="color: #ff6b35; font-weight: 600; margin-bottom: 20px;">
        <i class="fas fa-tag"></i> ${article.category}
    </p>
    ${article.content}
`;
```

Aquí puedes añadir autor, fecha, tiempo de lectura, etc.

---

## 📊 AGREGAR MÁS CATEGORÍAS

### Paso 1: Añade el Botón en HTML

```html
<button class="filter-btn" data-filter="motivacion">Motivación</button>
```

### Paso 2: Usa la Nueva Categoría

```html
<article class="blog-card" data-category="motivacion">
```

### Paso 3: El JavaScript lo detectará automáticamente ✓

---

## 📈 INTEGRACIONES FUTURAS RECOMENDADAS

### 1. Google Analytics

Añade en el `<head>` de blog.html:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_ID');
</script>
```

Luego en `js/blog-script.js`:

```javascript
blogCards.forEach(card => {
    card.addEventListener('click', () => {
        const title = card.querySelector('.blog-card-title').textContent;
        gtag('event', 'article_view', {
            'article_title': title
        });
    });
});
```

### 2. Comentarios (Disqus)

Añade en el modal antes de `</div>`:

```html
<div id="disqus_thread"></div>
<script>
    var disqus_config = function () {
        this.page.url = window.location.href;
        this.page.identifier = articleId;
    };
    // ... código de Disqus
</script>
```

### 3. Compartir en Redes Sociales

Añade botones en el modal:

```html
<div class="share-buttons">
    <a href="https://www.facebook.com/sharer/sharer.php?u=URL" target="_blank">
        <i class="fab fa-facebook"></i>
    </a>
    <a href="https://twitter.com/intent/tweet?url=URL" target="_blank">
        <i class="fab fa-twitter"></i>
    </a>
    <a href="https://www.linkedin.com/sharing/share-offsite/?url=URL" target="_blank">
        <i class="fab fa-linkedin"></i>
    </a>
</div>
```

### 4. Newsletter Email Service

Integra con Mailchimp, ConvertKit o similar:

```javascript
const newsletterForm = document.getElementById('newsletterForm');
newsletterForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = newsletterForm.querySelector('input[type="email"]').value;
    
    // Enviar a tu servicio de email
    await fetch('tu-api-endpoint', {
        method: 'POST',
        body: JSON.stringify({ email: email })
    });
    
    alert('¡Suscrito exitosamente!');
});
```

---

## 🐛 TROUBLESHOOTING

### El Modal No Abre

1. Verifica que `data-article="article-X"` existe en HTML
2. Verifica que la clave existe en `articlesData` en JavaScript
3. Abre la consola (F12) y busca errores

### Los Filtros No Funcionan

1. Verifica que `data-category` está escrito correctamente
2. Debe estar en minúsculas: `nutricion`, `fitness`, etc.
3. Revisa que el botón tiene `data-filter` con el mismo nombre

### La Búsqueda No Encuentra Artículos

1. Busca solo palabras que están en título o descripción
2. Es case-insensitive, así que "NUTRICIÓN" = "nutrición"

---

## 📱 TEMAS PARA CREAR ARTÍCULOS

### Nutrición (Ejemplos para Expandir)
- Guía de macronutrientes
- Carbohidratos vs Keto
- Proteína animal vs vegetal
- Suplementación basada en evidencia
- Hidratación y performance
- Alimentos antiinflamatorios
- Dieta mediterránea
- Ayuno intermitente científico

### Fitness (Ejemplos para Expandir)
- Periodización de entrenamientos
- Recuperación muscular
- Ejercicio post-lesión
- Entrenamiento funcional
- Movilidad y flexibilidad
- Circuitos de entrenamiento
- Ejercicios sin equipo
- Progresión de ejercicios

### Recetas (Ejemplos para Expandir)
- Bowls saludables
- Batidos proteicos
- Wraps y sándwiches
- Ensaladas principales
- Sopas nutritivas
- Postres sin azúcar
- Bebidas saludables
- Meal prep semanal

### Bienestar (Ejemplos para Expandir)
- Gestión del estrés
- Ansiedad y ejercicio
- Meditación guiada
- Respiración consciente
- Gestión del tiempo
- Rutinas de productividad
- Salud mental y fitness
- Trabajo-vida balance

### Inspiración (Ejemplos para Expandir)
- Cambios de hábito
- Mentalidad de crecimiento
- Superando limitaciones
- Testimonios de transformación
- Lecciones aprendidas
- Errores comunes a evitar
- Disciplina vs Motivación
- Sostenibilidad de cambios

---

## ✅ CHECKLIST PARA AÑADIR ARTÍCULOS

- [ ] Tarjeta creada en HTML con `data-article="article-X"` único
- [ ] Contenido añadido en JavaScript en `articlesData`
- [ ] `data-category` es válido (nutricion, fitness, etc.)
- [ ] Icono seleccionado del Font Awesome
- [ ] Título es impactante y SEO-friendly
- [ ] Descripción es seductora y clara
- [ ] Contenido es verificable y educativo
- [ ] Incluye al menos un `.highlight` con consejo
- [ ] Tiene H3 subtítulos para estructura
- [ ] El texto fluye naturalmente
- [ ] Pruebas en desktop y móvil

---

## 🔐 SEGURIDAD Y MANTENIMIENTO

### Backups Regulares

```bash
# Hacer backup de tu blog.html cada semana
cp blog.html blog.html.backup-$(date +%Y%m%d)
```

### Monitoreo

Revisa regularmente:
- ✓ Todos los links funcionan
- ✓ Imágenes cargan (si las usas)
- ✓ Mobile responsivo
- ✓ Velocidad de carga

### Updates

Cuando hagas cambios:
1. Modifica en un backup primero
2. Prueba en desktop y móvil
3. Verifica en navegadores diferentes
4. Sube la versión final

---

## 💡 TIPS PRO

1. **Usa palabras clave reales** - "Rutina HIIT" en lugar de "Ejercicio"
2. **Incluye números en títulos** - "5 Desayunos" vs "Desayunos Saludables"
3. **Sé específico en descripciones** - "Pierde grasa, no músculo" vs "Pierde peso"
4. **Usa directives de acción** - "Descubre", "Aprende", "Domina", "Vence"
5. **Incluye promesas claras** - "garantizado", "científicamente probado", "real"
6. **Haz content actualizado** - Revisa tus artículos cada 3 meses

---

**¡Tu blog es un activo que crece con tiempo! Mantenlo, expándelo, y verás los resultados.** 🚀

// CONTENIDO DEL ARTÍCULO: DIABETES TIPO 2
// Este archivo proporciona el contenido para mostrar en el modal de artículos del blog

const articleoDiabetesTipo2 = {
    id: 'diabetes-tipo-2',
    title: 'Diabetes Tipo 2: La Epidemia Silenciosa que SÍ Podemos Prevenir y Controlar',
    author: 'Francisco Valverde',
    date: '2 de Enero, 2026',
    readTime: '12 min',
    category: 'Salud',
    excerpt: 'Diabetes tipo 2: causas, síntomas, prevención y control. Descubre cómo revertirla en fases tempranas con hábitos saludables basados en ciencia.',
    
    content: `
    <div class="article-header">
        <h2 class="article-title">Diabetes Tipo 2: La Epidemia Silenciosa que SÍ Podemos Prevenir y Controlar</h2>
        <div class="article-meta">
            <span class="meta-author"><i class="fas fa-user"></i> Francisco Valverde</span>
            <span class="meta-date"><i class="fas fa-calendar"></i> 2 de Enero, 2026</span>
            <span class="meta-time"><i class="fas fa-clock"></i> 12 min lectura</span>
            <span class="meta-category"><i class="fas fa-tag"></i> Salud • Prevención</span>
        </div>
    </div>

    <div class="article-body">
        <!-- INTRODUCCIÓN -->
        <div class="article-intro">
            <p style="font-size: 1.15rem; font-weight: 500; color: #667eea;">
                La diabetes tipo 2 es una de las enfermedades metabólicas más extendidas del mundo. Representa entre el <strong>90 y el 95% de todos los casos de diabetes</strong> y su prevalencia sigue aumentando cada año.
            </p>
            <p style="font-size: 1.1rem; font-weight: 500;">
                <strong style="color: #667eea;">La buena noticia:</strong> en la mayoría de los casos, puede prevenirse, controlarse e incluso revertirse en fases tempranas mediante hábitos saludables basados en evidencia científica.
            </p>
        </div>

        <!-- ¿QUÉ ES DIABETES TIPO 2? -->
        <h3>¿Qué es la Diabetes Tipo 2?</h3>
        <p>
            La diabetes tipo 2 es una condición en la que los niveles de glucosa en sangre se mantienen elevados porque el cuerpo no produce suficiente insulina o no la utiliza correctamente (resistencia a la insulina).
        </p>
        <div class="highlight-box">
            <strong>La Insulina: La Llave que Abre las Células</strong>
            <p>
                La insulina es la "llave" que permite que la glucosa entre en las células para producir energía. Cuando falla este mecanismo, el azúcar se acumula en la sangre y aparecen síntomas y complicaciones.
            </p>
        </div>

        <!-- SÍNTOMAS -->
        <h3>Síntomas Más Comunes</h3>
        <p>Aunque puede ser silenciosa durante años, algunos signos de alerta incluyen:</p>
        <ul>
            <li>Sed excesiva y sequedad bucal</li>
            <li>Aumento de la frecuencia urinaria</li>
            <li>Cansancio persistente</li>
            <li>Visión borrosa</li>
            <li>Hambre constante</li>
            <li>Heridas que tardan en cicatrizar</li>
        </ul>

        <!-- FACTORES DE RIESGO -->
        <h3>Factores de Riesgo (La Buena Noticia: Son Modificables)</h3>
        <p>
            La evidencia científica muestra que los principales factores de riesgo son <strong>modificables</strong>. Esto significa que tienes el poder de cambiarlos:
        </p>
        <ul>
            <li><strong>Sobrepeso y obesidad</strong></li>
            <li><strong>Sedentarismo</strong></li>
            <li><strong>Alimentación alta en ultraprocesados y azúcares</strong></li>
            <li><strong>Estrés crónico y falta de sueño</strong></li>
            <li><strong>Antecedentes familiares</strong></li>
        </ul>

        <!-- COMPLICACIONES -->
        <h3>Complicaciones Si No Se Controla</h3>
        <p>La diabetes tipo 2 no controlada puede afectar:</p>
        <ul>
            <li><strong>Corazón y sistema cardiovascular</strong> - Aumenta riesgo de infarto</li>
            <li><strong>Riñones</strong> - Puede conducir a insuficiencia renal</li>
            <li><strong>Nervios</strong> - Neuropatía y pérdida de sensibilidad</li>
            <li><strong>Vista</strong> - Retinopatía diabética</li>
            <li><strong>Sistema inmunitario</strong> - Mayor susceptibilidad a infecciones</li>
        </ul>

        <!-- PREVENCIÓN -->
        <h3>¿Se Puede Prevenir? Sí, Definitivamente</h3>
        <p>
            Las guías clínicas más recientes destacan que <strong>los cambios de estilo de vida son la intervención más poderosa</strong> para prevenir y controlar la diabetes tipo 2.
        </p>
        <div class="highlight-box">
            <strong>Hábitos que Reducen Drásticamente el Riesgo:</strong>
            <ul>
                <li>Pérdida del 5–10% del peso corporal</li>
                <li>Actividad física regular (mínimo 150 minutos semanales)</li>
                <li>Alimentación basada en comida real</li>
                <li>Dormir 7–9 horas</li>
                <li>Gestión del estrés</li>
                <li>Reducción de ultraprocesados y azúcares</li>
            </ul>
        </div>

        <!-- TRATAMIENTOS -->
        <h3>Tratamientos Actuales</h3>
        <p>Las actualizaciones clínicas recientes destacan:</p>
        <ul>
            <li><strong>La metformina</strong> sigue siendo el tratamiento inicial más recomendado</li>
            <li><strong>Nuevos fármacos como los GLP‑1 RA y los SGLT2i</strong> ayudan a controlar la glucosa, favorecen la pérdida de peso y protegen el corazón y los riñones</li>
            <li><strong>El enfoque debe ser individualizado</strong> según cada persona</li>
        </ul>
        <p style="font-weight: 500; color: #667eea;">
            Pero incluso con medicación, los hábitos siguen siendo la base del tratamiento.
        </p>

        <!-- REVERSIÓN -->
        <h3>¿Se Puede Revertir la Diabetes Tipo 2?</h3>
        <p style="font-weight: 600; color: #667eea;">En fases tempranas, SÍ.</p>
        <p>
            La evidencia muestra que:
        </p>
        <ul>
            <li>La pérdida de peso significativa</li>
            <li>La reducción de grasa visceral</li>
            <li>La mejora de la sensibilidad a la insulina</li>
        </ul>
        <p>
            ...pueden llevar a una remisión parcial o total en muchos casos.
        </p>

        <!-- RECOMENDACIONES PRÁCTICAS -->
        <h3>Recomendaciones Prácticas para Actuar Hoy Mismo</h3>
        <ol>
            <li><strong>Prioriza alimentos reales</strong> y evita ultraprocesados</li>
            <li><strong>Camina o ejercita regularmente</strong> - 30 minutos diarios mínimo</li>
            <li><strong>Controla el tamaño de las porciones</strong></li>
            <li><strong>Bebe agua de forma constante</strong> - 2-3 litros diarios</li>
            <li><strong>Duerme bien y reduce el estrés</strong></li>
            <li><strong>Realiza controles médicos periódicos</strong></li>
        </ol>

        <!-- CONCLUSIÓN -->
        <h3>Conclusión</h3>
        <p>
            La diabetes tipo 2 es una enfermedad seria, pero también es una de las más influenciadas por nuestros hábitos. Con educación, acompañamiento y cambios sostenibles, es posible prevenirla, controlarla y mejorar radicalmente la calidad de vida.
        </p>
        <p style="font-weight: 600; color: #667eea;">
            Tu transformación no comienza mañana. Comienza con la próxima decisión que tomas hoy.
        </p>
    </div>
    `
};

// Exportar para uso en otros scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = articleoDiabetesTipo2;
}

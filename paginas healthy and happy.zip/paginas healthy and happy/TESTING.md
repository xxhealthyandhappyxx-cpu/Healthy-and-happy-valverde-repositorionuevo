## 🧪 GUÍA DE TESTING Y VALIDACIÓN

### 📋 ANTES DE EMPEZAR
1. Asegúrate de tener las imágenes en `images/`
2. Abre la página en localhost
3. Abre la consola del navegador (F12)

---

## ✅ TEST 1: ESTRUCTURA HTML

### Verificar que todos los archivos existan:
```
✓ index-home.html
✓ css/home-style.css
✓ js/home-script.js
✓ images/logo-header.png
✓ images/francisco-perfil.png
```

### Validar HTML:
1. Abre: https://validator.w3.org/
2. Sube el archivo `index-home.html`
3. No debe haber errores críticos

---

## ✅ TEST 2: MENÚ Y NAVEGACIÓN

### Menú Desktop:
- [ ] Menú visible en la parte superior
- [ ] Todos los items aparecen (Inicio, Sobre Nosotros, Servicios, Contenido, Comunidad, Contáctanos)
- [ ] Dropdowns abren al pasar el mouse
- [ ] Dropdowns cierran al salir
- [ ] Links funcionan correctamente
- [ ] Colores se ven correctamente (rojo y verde)

### Menú Móvil (320px - 768px):
- [ ] Botón hamburguesa visible
- [ ] Al hacer clic, menú se abre
- [ ] Al hacer clic nuevamente, menú se cierra
- [ ] Dropdowns funcionan al hacer clic
- [ ] Links cierran el menú automaticamente

---

## ✅ TEST 3: SECCIONES Y CONTENIDO

### Hero Section:
- [ ] Imagen de fondo se ve correctamente
- [ ] Título y subtítulo visibles
- [ ] Botones "Comienza Ahora" y "Contáctame" funcionan
- [ ] Responsivo en todos los tamaños

### About Section:
- [ ] Texto descriptivo visible
- [ ] Lista de características aparece correctamente
- [ ] Imagen de perfil se carga
- [ ] Responsive en tablet y móvil

### Services Section:
- [ ] 6 tarjetas de servicios visibles
- [ ] Iconos se cargan correctamente
- [ ] Efectos hover funcionan (elevan la tarjeta)
- [ ] Links "Ver Más" funcionan

### Media Section:
- [ ] Enlaces a Spotify y YouTube visibles
- [ ] Links funcionales
- [ ] Iconos se ven bien

### Book Section:
- [ ] Información del libro visible
- [ ] Precios mostrados correctamente
- [ ] Botón "Pre-Ordenar" funciona
- [ ] Responsive en móvil

### Testimonials Section:
- [ ] 3 testimonios visibles
- [ ] Estrellas aparecen
- [ ] Responsive en todos los tamaños

### Contact Section:
- [ ] Formulario completo visible
- [ ] Campos de entrada funcionan
- [ ] Redes sociales mostradas

### Footer:
- [ ] Enlaces rápidos funcionan
- [ ] Redes sociales (7 iconos) visibles
- [ ] Newsletter form funciona
- [ ] Copyright visible

---

## ✅ TEST 4: FORMULARIOS

### Formulario de Contacto:
1. Intenta enviar sin datos
   - [ ] Debe mostrar mensaje de error
2. Intenta con email inválido (ej: "asd")
   - [ ] Debe mostrar error de email
3. Completa correctamente:
   - Nombre: "Juan"
   - Email: "juan@email.com"
   - Asunto: "Consulta"
   - Mensaje: "Quiero información"
   - [ ] Debe mostrar mensaje de éxito
   - [ ] Formulario debe limpiarse

### Formulario Newsletter:
1. Intenta sin email
   - [ ] Debe mostrar error
2. Intenta con email inválido
   - [ ] Debe mostrar error
3. Ingresa email válido
   - [ ] Debe mostrar mensaje de éxito

---

## ✅ TEST 5: EFECTOS Y ANIMACIONES

- [ ] Animaciones de carga suave en elementos
- [ ] Hover effects en botones (cambio de color)
- [ ] Hover effects en tarjetas (se elevan)
- [ ] Hover effects en links (subrayado)
- [ ] Scroll suave al hacer clic en links internos
- [ ] Notificaciones aparecen en esquina superior derecha

---

## ✅ TEST 6: RESPONSIVIDAD

### Desktop (1920px):
- [ ] Menú horizontal completo
- [ ] Contenido en múltiples columnas
- [ ] Todo se ve perfecto

### Laptop (1024px):
- [ ] Grid de servicios con 3 columnas
- [ ] Menú aún horizontal
- [ ] Espaciado correcto

### Tablet (768px):
- [ ] Menú hamburguesa aparece
- [ ] Grid de servicios con 2 columnas
- [ ] Texto legible
- [ ] Botones táctiles

### Móvil pequeño (480px):
- [ ] Grid de servicios con 1 columna
- [ ] Todos los elementos visibles
- [ ] Texto escalado correctamente
- [ ] Botones fáciles de pulsar

---

## ✅ TEST 7: IMÁGENES

- [ ] Logo en header carga correctamente
- [ ] Foto de perfil en About carga correctamente
- [ ] Formato PNG comprimido
- [ ] Sin errores 404 en consola

---

## ✅ TEST 8: REDES SOCIALES

Verifica que cada icono en el footer:
- [ ] Instagram - Abre tu perfil en pestaña nueva
- [ ] Facebook - Abre tu página en pestaña nueva
- [ ] TikTok - Abre tu cuenta en pestaña nueva
- [ ] YouTube - Abre tu canal en pestaña nueva
- [ ] LinkedIn - Abre tu perfil en pestaña nueva
- [ ] X/Twitter - Abre tu cuenta en pestaña nueva
- [ ] Pinterest - Abre tu perfil en pestaña nueva

---

## ✅ TEST 9: VELOCIDAD DE PÁGINA

### Uso de PageSpeed Insights:
1. Ve a: https://pagespeed.web.dev/
2. Ingresa tu URL (cuando esté publicada)
3. Verifica:
   - [ ] Performance > 80
   - [ ] Accessibility > 80
   - [ ] Best Practices > 80
   - [ ] SEO > 80

### Optimizaciones locales:
- [ ] Imágenes comprimidas
- [ ] CSS minificado
- [ ] JavaScript minificado
- [ ] Sin scripts bloqueantes

---

## ✅ TEST 10: COMPATIBILIDAD NAVEGADORES

### Chrome (Versión actual):
- [ ] Se ve correctamente
- [ ] Todas las funciones funcionan
- [ ] Sin errores en consola

### Firefox (Versión actual):
- [ ] Se ve correctamente
- [ ] Menú funciona
- [ ] Formularios funcionan

### Safari (Versión actual):
- [ ] Se ve correctamente
- [ ] Sin problemas de estilos
- [ ] Responsive funciona

### Edge (Versión actual):
- [ ] Se ve correctamente
- [ ] JavaScript funciona

### Mobile Safari (iOS):
- [ ] Menú hamburguesa funciona
- [ ] Formularios son táctiles
- [ ] Responsive correcto

### Chrome Mobile (Android):
- [ ] Responsive correcto
- [ ] Menú funciona
- [ ] Botones están espaciados bien

---

## ✅ TEST 11: ACCESIBILIDAD

### Teclado:
- [ ] Puedo navegar con Tab
- [ ] Puedo activar dropdowns con Enter
- [ ] Puedo enviar formularios con Enter
- [ ] Enfoque visible en elementos interactivos

### Colores:
- [ ] Contraste suficiente (texto vs fondo)
- [ ] No depende solo del color

### Iconos:
- [ ] Todos tienen alt text
- [ ] Describen correctamente

---

## ✅ TEST 12: SEO

### Meta Tags:
1. Abre el HTML en editor de texto
2. Verifica:
   - [ ] `<title>` descriptivo
   - [ ] `<meta name="description">`
   - [ ] `<meta name="keywords">`
   - [ ] Open Graph tags

### Estructura:
- [ ] H1 presente (solo una)
- [ ] H2, H3 jerarquizadas correctamente
- [ ] Alt text en imágenes
- [ ] Links con texto descriptivo

### Robots:
- [ ] Sin errores en console sobre robots.txt

---

## ✅ TEST 13: CONSOLA DEL NAVEGADOR

Al abrir F12 -> Console:
- [ ] No hay errores rojos (Errors)
- [ ] Warnings amarillos son aceptables
- [ ] Sin errores de CORS
- [ ] Sin 404 en archivos

---

## ✅ TEST 14: COMPORTAMIENTO EN DIFERENTES CONTEXTOS

### Con JavaScript deshabilitado:
- [ ] Página aún es legible (degradación elegante)
- [ ] Al menos la estructura HTML funciona

### Con imágenes deshabilitadas:
- [ ] Alt text visible
- [ ] Página aún es funcional

### Con conexión lenta:
- [ ] Página carga progresivamente
- [ ] Usuario puede interactuar mientras carga

---

## ✅ TEST 15: ENLACES INTERNOS Y EXTERNOS

### Enlaces internos:
- [ ] Enlace "Inicio" scroll a top
- [ ] Enlace "Sobre Nosotros" scroll a sección
- [ ] Enlace "Servicios" scroll a sección
- [ ] Enlace "Contacto" scroll a sección

### Enlaces externos:
- [ ] Todos abren en pestaña nueva (_blank)
- [ ] No hay enlaces rotos
- [ ] Redes sociales abren correctamente

---

## 📊 REPORTE FINAL

### Antes de publicar, verifica:

```
ESTRUCTURA        [  ] Completa y válida
MENÚ              [  ] Funcional en todos los tamaños
FORMULARIOS       [  ] Validación funcionando
RESPONSIVIDAD     [  ] Probado en 4+ tamaños
IMÁGENES          [  ] Cargando correctamente
VELOCIDAD         [  ] Optimizada
ACCESIBILIDAD     [  ] Accesible
SEO               [  ] Meta tags correctos
NAVEGADORES       [  ] Probado en 6+
REDES SOCIALES    [  ] Todos los links funcionan
```

---

## 🚀 LISTA DE DESPLIEGUE

Una vez validado todo:

1. [ ] Backup local
2. [ ] FTP/SFTP configurado
3. [ ] Archivos subidos al servidor
4. [ ] DNS/Dominio configurado
5. [ ] SSL/HTTPS instalado
6. [ ] Email configurado
7. [ ] Analytics configurado
8. [ ] Backup en servidor
9. [ ] Sitemap.xml generado
10. [ ] robots.txt configurado

---

## 📞 RESOLUCIÓN DE PROBLEMAS

### Si algo no funciona:

1. **Abre la consola**: F12
2. **Busca mensajes rojos** (errors)
3. **Nota la línea y archivo**
4. **Verifica**:
   - ¿Existen todos los archivos?
   - ¿Los nombres son exactos?
   - ¿Las rutas son correctas?
5. **Recarga**: Ctrl+Shift+R (limpiar caché)

---

## ✨ CHECKLIST FINAL ANTES DE PUBLICAR

- [ ] Todas las pruebas pasaron
- [ ] No hay errores en consola
- [ ] Velocidad de página aceptable
- [ ] Mobile friendly confirmado
- [ ] SSL/HTTPS instalado
- [ ] Formularios enlazan a backend
- [ ] Analytics configurado
- [ ] Backup realizado
- [ ] Dominio apunta correctamente

---

**¡Felicidades! Tu página está lista para el mundo.** 🎉

**No es el peso que pierdes, ¡es la vida que ganas!** 💪
